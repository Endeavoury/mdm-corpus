"""Audit document integrity, never empirical prototype performance."""
import csv, hashlib, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def read(name):
    raw=(ROOT/name).read_bytes()
    assert raw.startswith(b'\xef\xbb\xbf'),f'Missing UTF-8 BOM: {name}'
    with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert rows and all(None not in r and all(v is not None for v in r.values()) for r in rows),name
    return rows
s=read('standards-matrix.csv');l=read('literature-matrix.csv');c=read('claims-register.csv');t=read('traceability-matrix.csv')
for rows,key in [(s,'id'),(l,'id'),(c,'claim_id'),(t,'requirement')]:
    assert len({r[key] for r in rows})==len(rows),f'Duplicate {key}'
known={r['id'] for r in s+l}
bib=(ROOT/'references.bib').read_text()
bibkeys=re.findall(r'@\w+\{([^,]+),',bib)
assert len(bibkeys)==len(set(bibkeys)) and set(bibkeys)==known
texfiles=[ROOT/'paper.tex']+sorted((ROOT/'sections').glob('*.tex'))
text='\n'.join(p.read_text() for p in texfiles)
cites={k.strip() for group in re.findall(r'\\cite\w*\{([^}]+)\}',text) for k in group.split(',')}
assert cites<=known,cites-known
assert 'L06' not in cites,'Metadata-only L06 must not support findings'
labels=re.findall(r'\\label\{([^}]+)\}',text)
assert len(labels)==len(set(labels))
assert set(re.findall(r'\\(?:ref|pageref)\{([^}]+)\}',text))<=set(labels)
for target in re.findall(r'\\input\{([^}]+)\}',text):assert (ROOT/(target+'.tex')).exists(),target
for r in c:
    refs=set(re.findall(r'\b[SL]\d{2}\b',r['bron_ids']))
    assert refs<=known,(r['claim_id'],refs-known)
reqs={f'R{i:02d}' for i in range(1,24)}
assert {r['requirement'] for r in t}==reqs
assert reqs<={r['claim_id'] for r in c}
for r in t:
    assert set(r['literature_and_standards'].split(';'))<=known
    assert r['evaluation_status']=='Voorgesteld; niet uitgevoerd'
    n=int(r['requirement'][1:]);assert r['proposed_evaluation_metric']==f'M{n:02d}' and r['test_id']==f'T{n:02d}'
    for field in ['research_question','design_principle','architecture_component']:
        assert r[field]

def union(field):return {v for r in t for v in r[field].split(';')}
assert union('research_question')=={f'OV{i}' for i in range(1,7)}
assert union('design_principle')=={f'DP{i}' for i in range(1,10)}
assert union('architecture_component')=={f'C{i}' for i in range(1,16)}
for phrase in ['de resultaten tonen aan','het prototype bewijst','de test bevestigt']:
    assert phrase not in text.lower(),phrase
# Source URLs must come from matrix fields, including registered source-location URLs.
urlpool='\n'.join(str(v) for row in s+l for v in row.values())
urls=re.findall(r'^  url = \{([^}]+)\}',bib,re.M)
assert all(u in urlpool for u in urls),'New bibliographic source URL'
log=(ROOT/'paper.log').read_text(errors='replace') if (ROOT/'paper.log').exists() else ''
issues=[]
for pattern in [r'LaTeX Warning:.*undefined',r'Package natbib Warning:.*undefined',r'Overfull \\[hv]box',r'^! ']:
    issues+=re.findall(pattern,log,re.M)
assert not issues,issues
blg=(ROOT/'paper.blg').read_text(errors='replace')
assert 'Warning--' not in blg and 'error message' not in blg, 'BibTeX warnings or errors'
pdf=ROOT/'paper.pdf'
assert pdf.exists() and pdf.stat().st_size>10000,'Compile PDF before final audit'
sha=hashlib.sha256(pdf.read_bytes()).hexdigest()
report=f'''# Traceability-audit van het manuscript

Uitgevoerd op 7 september 2026. Dit is een documentaudit, geen empirische evaluatie van het prototype.

## Gecontroleerde dekking

- {len(s)} standaard-/kadervermeldingen en {len(l)} literatuurvermeldingen in het bestaande corpus.
- {len(bibkeys)} unieke bibliografiesleutels; {len(cites)} daarvan aangehaald in het manuscript.
- Alle bibliografische bron-URL’s zijn terug te vinden in de bestaande matrices; geen nieuwe inhoudelijke bronnen toegevoegd.
- {len(c)} unieke claims; oorspronkelijke CSV-kolommen en UTF-8 BOM behouden.
- 23 requirements, 9 ontwerpprincipes, 15 architectuurcomponenten en 23 toekomstige meetcriteria verbonden met alle 6 deelvragen.
- Elke requirement heeft minimaal één bron, principe, component en toekomstige metriek. Alle verwijzingen in de traceability-matrix zijn opgelost.
- TeX-inputbestanden, interne labels en citaties gecontroleerd. Geen onopgeloste referenties, ontbrekende bibliografische jaren of overvolle tekstvakken in de definitieve logs. Niet vastgestelde publicatiejaren zijn expliciet `z.d.`. Resterende underfull-boxmeldingen betreffen woordspatiëring; representatieve pagina’s zijn visueel gecontroleerd.
- L06 ondersteunt geen inhoudelijke claim; S46/L11 en S50/L10 worden niet als onafhankelijk bewijs geteld.

## Inhoudelijke afbakeningscontrole

De paper onderscheidt bronbevindingen, ontwerpafleidingen, principes, voorgestelde architectuur, bestaand prototype en toekomstige evaluatie. R23, DP1–DP9 en P01–P06 zijn als eigen voorstellen/afbakening aan het claims-register toegevoegd. De kern van DP9 is een samengestelde epistemische annotatie, geen bestaande normclassificatie.

De casus blijft een BAG-fragment. BRP-, BRK- en WOZ-koppelingen zijn expliciet onbevestigde onderzoekspaden. Er zijn geen prototypefuncties, empirische testuitkomsten, normclausules, paginanummers of aanvullende bronmetadata verzonnen. AI-meerwaarde en ontologische meerwaarde blijven hypothesen. MOET in requirements en principes betreft het voorgestelde profiel; wettelijke toepasselijkheid wordt afzonderlijk beoordeeld.

De inhoudelijke controle is een redactionele zelfcontrole, geen onafhankelijke peer review. Intern volledige traceability bewijst geen inhoudelijke volledigheid van het corpus, juistheid van mappings of werking van het artefact. Officiële bronpagina’s zijn tijdens het schrijven niet opnieuw geraadpleegd. Peildatum en bewijsniveau van het dossier blijven gelden.

## Compilatie en artefact

Gecompileerd met Tectonic 0.17.0 en BibTeX/`plainnat`; bibliografie opgenomen in de PDF. Alleen de compiler en zijn TeX-afhankelijkheden zijn gedownload; deze downloads zijn geen onderzoeksbronnen.

- PDF: `paper.pdf`
- SHA-256: `{sha}`
- Reproduceerbare controles: `python scripts/prepare_paper.py`, `tectonic -k --keep-logs paper.tex`, `python scripts/audit_paper.py`.
- Machineleesbare keten: `traceability-matrix.csv`; dezelfde keten staat expliciet in bijlage A van de paper.

## Nog niet uitgevoerd

Geen onafhankelijke inhoudelijke validatie, prototype-inventarisatie buiten deze repository, SHACL-/OWL-prototypetoets, clausuleconformiteitstoets, gebruikersstudie, AI-experiment of empirische A/B-vergelijking. Ook de voorgestelde gouden standaard, steekproef en acceptatiebesluiten moeten nog worden vastgesteld.
'''
(ROOT/'traceability-audit.md').write_text(report)
print(f'PASS: {len(cites)} citation keys, {len(c)} claims, 23 complete traceability chains. PDF SHA256 {sha}')
